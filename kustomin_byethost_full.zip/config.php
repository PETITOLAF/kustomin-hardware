<?php
// Configuration - remplis avec tes valeurs
define('STRIPE_SECRET_KEY', 'sk_test_replace_me');
define('ORDER_EMAILS', 'frozekujo@gmail.com,clemfrdz@gmail.com');
// From email used in headers for mail()
define('FROM_EMAIL', 'noreply@tondomaine.com');
// Base URL of your site, e.g. https://tondomaine.byethost.com
define('BASE_URL', 'http://localhost'); // modifier en prod
?>